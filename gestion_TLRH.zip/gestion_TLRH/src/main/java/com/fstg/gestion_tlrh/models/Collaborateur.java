package com.fstg.gestion_tlrh.models;
import java.io.Serializable;
import java.util.Date;
//import java.util.List;
import javax.persistence.*;



import lombok.*;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor

public class Collaborateur implements Serializable {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer idCollaborateur;
	
	@Column()
	private String email;

	@Column
	private String password;

	@Column()
	private String matricul;

	@Column()
	private String nom_collaborateur;

	@Column()
	private String prenom_collaborateur;

	@Column()
	private String abreviation_collaborateur;

	@Column()
	private String ancien_manager_rh;

	@Column()
	private String managerrh_actuel;

	@Column()
	private String site;

	@Column()
	private String sexe;

	@Column()
	private String BU;

	@Column()
	private Date date_embauche;

	@Column()
	private String mois_bap;

	@Column()
	private Date date_depart;

	@Column()
	private Boolean Ancien_Collaborateur;

	@Column()
	private Boolean Seminaire_Intrgration;

	@Column()
	private Date Date_Participation;

	@Column()
	private String PosteAPP;

	@Column()
	private String PosteActuel;

	@Column()
	private Integer Salaire_Actuel;

	@Column()
	private Boolean StatutManagerRh;

	//============================implementation des relations=================================
	@ManyToOne
	private Archivage archivage;

	@OneToOne
	private Diplome diplome;

	@ManyToOne
	private Ecole ecole;

	@ManyToOne
	private Role role;

	@ManyToOne
	private Technologie tech;
//================constructeur de copie=========================
	public Collaborateur(Collaborateur cl) {

		this.email=cl.email;

		this.idCollaborateur=cl.idCollaborateur;
		this.password=cl.password;

		this.matricul=cl.matricul;

		this.nom_collaborateur=cl.nom_collaborateur;

		this.prenom_collaborateur=cl.prenom_collaborateur;

		this.abreviation_collaborateur=cl.abreviation_collaborateur;

		this.ancien_manager_rh=cl.ancien_manager_rh;

		this.managerrh_actuel=cl.managerrh_actuel;

		this.site=cl.site;

		this.sexe=cl.sexe;

		this.BU=cl.BU;

		this.date_embauche=cl.date_embauche;

		this.mois_bap=cl.mois_bap;

		this.date_depart=cl.date_depart;

		this.Ancien_Collaborateur=cl.Ancien_Collaborateur;

		this.Seminaire_Intrgration=cl.Seminaire_Intrgration;

		this.Date_Participation=cl.Date_Participation;

		this.PosteAPP=cl.PosteAPP;

		this.PosteActuel=cl.PosteActuel;

		this.Salaire_Actuel=cl.Salaire_Actuel;

		this.StatutManagerRh = cl.StatutManagerRh;


		//this.archivage=cl.archivage;
		//this.diplome=cl.diplome;
		//this.ecole=cl.ecole;
		//this.role=cl.role;
	//	this.tech=cl.tech;
	}


}
