package com.fstg.gestion_tlrh.dao;

import com.fstg.gestion_tlrh.models.Diplome;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;


public interface DiplomeRepository extends JpaRepository<Diplome,Integer> {


    List<Diplome> save(List<Diplome> diplomes);
}
