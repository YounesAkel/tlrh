package com.fstg.gestion_tlrh.service;

import java.util.*;

import com.fstg.gestion_tlrh.dao.*;
import com.fstg.gestion_tlrh.models.*;

import org.springframework.boot.context.config.ConfigDataResourceNotFoundException;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;

import javax.transaction.Transactional;

@Service

public class CollaborateurServiceImpl {



	@Autowired
	private ColaborateurRepository collaborateurdao;//type Collaborateur public interface ColaborateurRepository extends JpaRepository<Collaborateur,Integer>

	@Autowired
	private ArchivageRepository archivagedao;

	@Autowired
	private DiplomeRepository diplomedao;

	@Autowired
	private EcoleRepository ecoledao;

	@Autowired
	private RoleRepository roledao;

	@Autowired
	private TechnologieRepository techdao;

	public CollaborateurServiceImpl() {}
	//===========================================================================================

	//******************************************************************************************************************


	public Collaborateur save(Collaborateur r) {
		Collaborateur savedcollab=collaborateurdao.save(r);

		return savedcollab;
	}

	//===============================gestion de collaborateur===========================================
	public List<Collaborateur> GetAllcollab() {
		return collaborateurdao.findAll();
	}
	public Optional<Collaborateur> GetSinglecollab(Integer id) {

		return collaborateurdao.findById(id);
	}
	public Collaborateur Ajout_Collaborateur(Collaborateur cl) {

		//Optional<Collaborateur> findcollab=collaborateurdao.findById(cl.getIdCollaborateur());

//ici j'ai utiliser existebyid au lieu de findbyid car j'ai pas besoin de la methode get
// qui est utiliser apres findbyid pour recuperer les donner
// cela car mon but est de crer un nouveau collaborayeur et pas de modifier ces infos
		if(collaborateurdao.existsById(cl.getIdCollaborateur())){
			throw new RuntimeException("collaborateur deja existe");
		}else{
			Collaborateur collab=new Collaborateur(
					cl.getIdCollaborateur(),
					cl.getEmail(),
					cl.getPassword(),
					cl.getMatricul(),
					cl.getNom_collaborateur(),
					cl.getPrenom_collaborateur(),
					cl.getAbreviation_collaborateur(),
					cl.getAncien_manager_rh(),
					cl.getManagerrh_actuel(),
					cl.getSite(),
					cl.getSexe(),
					cl.getBU(),
					cl.getDate_embauche(),
					cl.getMois_bap(),
					cl.getDate_depart(),
					cl.getAncien_Collaborateur(),
					cl.getSeminaire_Intrgration(),
					cl.getDate_Participation(),
					cl.getPosteAPP(),
					cl.getPosteActuel(),
					cl.getSalaire_Actuel(),
					cl.getStatutManagerRh(),
					archivagedao.save(cl.getArchivage()),
					diplomedao.save(cl.getDiplome()),
					ecoledao.save(cl.getEcole()),
					roledao.save(cl.getRole()),
					techdao.save(cl.getTech())
			);



			Collaborateur savedcollab=collaborateurdao.save(collab);

			return savedcollab;

		}



	}


	public Collaborateur modifier_Collaborateur(Collaborateur cl, Integer id) {

		Optional<Collaborateur> findcollab=collaborateurdao.findById(id);
//ici mon but est de modifier les données du collaborateur donc j'ai utiliser findbyid
// car je suis besoin de la methode get qui vient apres findbyid pour recuperer les anciens données
		if(findcollab.isPresent()){

         Collaborateur collab=findcollab.get();

         // Collaborateur updated=new Collaborateur(cl);

			collab.setIdCollaborateur(cl.getIdCollaborateur()) ;

			collab.setEmail(cl.getEmail() ) ;

			collab.setPassword(cl.getPassword() ) ;

			collab.setMatricul(cl.getMatricul() ) ;

			collab.setNom_collaborateur(cl.getNom_collaborateur() ) ;

			collab.setPrenom_collaborateur(cl.getPrenom_collaborateur() ) ;

			collab.setAbreviation_collaborateur(cl.getAbreviation_collaborateur() );

			collab.setAncien_manager_rh(cl.getAncien_manager_rh() ) ;

			collab.setManagerrh_actuel(cl.getManagerrh_actuel() ) ;

			collab.setSite(cl.getSite() ) ;

			collab.setSexe(cl.getSexe() ) ;

			collab.setBU(cl.getBU() ) ;

			collab.setDate_embauche(cl.getDate_embauche() ) ;

			collab.setMois_bap(cl.getMois_bap() ) ;

			collab.setDate_depart(cl.getDate_depart() );

			collab.setAncien_Collaborateur(cl.getAncien_Collaborateur() ) ;

			collab.setSeminaire_Intrgration(cl.getSeminaire_Intrgration() ) ;

			collab.setDate_Participation(cl.getDate_Participation() );

			collab.setPosteAPP(cl.getPosteAPP() ) ;

			collab.setPosteActuel(cl.getPosteActuel() );

			collab.setSalaire_Actuel(cl.getSalaire_Actuel() ) ;

			collab.setStatutManagerRh(cl.getStatutManagerRh() ) ;

		//	collab.setArchivage(cl.getArchivage() ) ;

		//	collab.setDiplome(cl.getDiplome() ) ;

		//	collab.setEcole(cl.getEcole() ) ;

		//	collab.setRole(cl.getRole() ) ;

		//	collab.setTech(cl.getTech() );

		  Collaborateur savedUpdate=collaborateurdao.save(collab);

       return savedUpdate;
		}
				else{
		throw new RuntimeException("collab not found");
		}//throw = return
	}

public Map<String,Boolean> deletecollab(Integer idcollab){
		Collaborateur foundcollab=collaborateurdao.findById(idcollab).orElseThrow(() ->
				new RuntimeException("Employee not exist with id :" + idcollab));
		 collaborateurdao.delete(foundcollab);
		 Map<String,Boolean> rsp=new HashMap<>();

		 rsp.put("deleted",Boolean.TRUE);
	return rsp;
}

	public void envoie_email(Collaborateur collaborateur) {
		String collaborateurMail=collaborateur.getEmail();
		boolean manager=collaborateur.getStatutManagerRh();
		if(manager) {
			String managerMail = collaborateur.getEmail();
			String sexe = collaborateur.getSexe().equals("Female") ? "Mrs" : "Mr";
			EmailSenderService.sendemail(
					managerMail,
					"New Employee ",
					"Hi "+sexe+" "+collaborateur.getPrenom_collaborateur()+" "+collaborateur.getNom_collaborateur()+
							" Your new Employee is : " + collaborateur.getPrenom_collaborateur() +
							" " + collaborateur.getNom_collaborateur() + " the email is : " + collaborateurMail
					);
		}else {
			EmailSenderService.sendemail
					(collaborateurMail,
					" SQLI ",
					"Hi Dear welcome to SQLI . "
			);
		}
	}


	//=================================gestion des mangers RH========================================

	public Collaborateur creat_managerRH(Collaborateur managerrh) {


		if(managerrh.getStatutManagerRh()){
			throw new RuntimeException("manager rh deja exist");
		}else {
			boolean ismangerrh = true;

			managerrh.setStatutManagerRh(ismangerrh);
			Collaborateur collab = new Collaborateur(
					managerrh.getIdCollaborateur(),
					managerrh.getEmail(),
					managerrh.getPassword(),
					managerrh.getMatricul(),
					managerrh.getNom_collaborateur(),
					managerrh.getPrenom_collaborateur(),
					managerrh.getAbreviation_collaborateur(),
					managerrh.getAncien_manager_rh(),
					managerrh.getManagerrh_actuel(),
					managerrh.getSite(),
					managerrh.getSexe(),
					managerrh.getBU(),
					managerrh.getDate_embauche(),
					managerrh.getMois_bap(),
					managerrh.getDate_depart(),
					managerrh.getAncien_Collaborateur(),
					managerrh.getSeminaire_Intrgration(),
					managerrh.getDate_Participation(),
					managerrh.getPosteAPP(),
					managerrh.getPosteActuel(),
					managerrh.getSalaire_Actuel(),
					managerrh.getStatutManagerRh(),
					archivagedao.save(managerrh.getArchivage()),
					diplomedao.save(managerrh.getDiplome()),
					ecoledao.save(managerrh.getEcole()),
					roledao.save(managerrh.getRole()),
					techdao.save(managerrh.getTech())
			);


			Collaborateur savedcollab = collaborateurdao.save(collab);

			return savedcollab;
		}
	}


	public Collaborateur assign_to_mangerRH(Integer collaborateurId) {
      Optional<Collaborateur> findcollab=collaborateurdao.findById(collaborateurId);
if(findcollab.isPresent()){
	Collaborateur recup=findcollab.get();
	if(recup.getStatutManagerRh()){
		throw new RuntimeException("ce collaborateur est deja manager rh");
	}else{
	boolean ismangerrh = true;
       Collaborateur recupmanager=findcollab.get();
		recupmanager.setStatutManagerRh(ismangerrh);

		Collaborateur savedmanagerrh=collaborateurdao.save(recupmanager);
		return savedmanagerrh;
	}
}else{
	throw new RuntimeException("collaborateur n'existe pas");
}
	}
//=================================================== reporting ====================================







}
