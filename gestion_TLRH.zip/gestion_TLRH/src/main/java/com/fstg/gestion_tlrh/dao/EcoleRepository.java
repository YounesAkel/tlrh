package com.fstg.gestion_tlrh.dao;

import com.fstg.gestion_tlrh.models.Ecole;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EcoleRepository extends JpaRepository<Ecole,Integer> {

    Ecole save(Ecole ecole);

}
