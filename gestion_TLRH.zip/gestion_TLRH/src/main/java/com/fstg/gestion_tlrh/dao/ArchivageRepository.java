package com.fstg.gestion_tlrh.dao;

import com.fstg.gestion_tlrh.models.Archivage;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ArchivageRepository extends JpaRepository<Archivage,Integer> {

    Archivage save(Archivage arch);

}
