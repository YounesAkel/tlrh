package com.fstg.gestion_tlrh.dao;

import com.fstg.gestion_tlrh.models.Technologie;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TechnologieRepository extends JpaRepository<Technologie,Integer> {

    Technologie save(Technologie tech);
}
