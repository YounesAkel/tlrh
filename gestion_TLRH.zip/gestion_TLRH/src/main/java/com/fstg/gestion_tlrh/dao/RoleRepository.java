package com.fstg.gestion_tlrh.dao;

import com.fstg.gestion_tlrh.models.Role;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RoleRepository extends JpaRepository<Role,Integer> {

    Role save(Role r);
}
