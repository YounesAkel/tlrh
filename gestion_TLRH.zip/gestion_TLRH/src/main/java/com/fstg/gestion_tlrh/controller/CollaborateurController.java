package com.fstg.gestion_tlrh.controller;
import com.fstg.gestion_tlrh.models.*;
import com.fstg.gestion_tlrh.service.CollaborateurServiceImpl;
import com.fstg.gestion_tlrh.service.EmailSenderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;



import java.util.List;
import java.util.Map;
import java.util.Optional;

@RestController
@CrossOrigin(origins = "http://localhost:4200/")
@RequestMapping("/collaborateurs")
public class CollaborateurController {

    //dans la class controleur on va crée une autre fonction qui fait appele à la fonction précédante implémenté dans la class service
    //    //cette fonction prend les mémes paramétres et type de retourd que la premiére

    /*les annotations @Data,@AllArgsConstructor,@NoArgsConstructor à éviter pour la class de la couche controleur et remplacer par @Autowired*/

    @Autowired
    private CollaborateurServiceImpl collabService=new CollaborateurServiceImpl();




    //************************************gestion collaborateur*******************************************************************
//afficher la liste des collaborateurs
    @GetMapping("/collab")
    public List<Collaborateur> getAllCollab(){
        return  collabService.GetAllcollab();    }

    @GetMapping("/collab/{id}")
    public Optional< Collaborateur> GetSinglecollab(@PathVariable Integer id){
        return  collabService.GetSinglecollab(id);    }
    //------------------------------------------------------------
    //ajout d'un nouveau collaborateur
   /* @PostMapping ("/collab")
    public ResponseEntity<Collaborateur> saveCollab(@RequestBody() Collaborateur cl){
        return new ResponseEntity<>(collabService.save(cl), HttpStatus.CREATED);
    }*/
//---------------------------------
    @PostMapping ("/collab")// chemin: /collaborateurs/ajout

    public ResponseEntity<Collaborateur> ajout_collab(@RequestBody Collaborateur cl){
        return new ResponseEntity<>(collabService.Ajout_Collaborateur(cl), HttpStatus.CREATED);
    }
    //-----------------------------------------------------------------------------
//modifier un collaborateur
    @PutMapping("/collab/{id}")/*pour update on utilise la methode @PutMapping() et pour delete on utilise @DeleteMapping() s'il s'agit
                                    pas d'une parmi ces deux et contient une partie dynamique on utilise @GetMapping sinon @PostMapping()*/
    public ResponseEntity<Collaborateur> modifier_collab(@RequestBody() Collaborateur cl,@PathVariable("id") Integer id){
        return new ResponseEntity<>(collabService.modifier_Collaborateur(cl,id),HttpStatus.ACCEPTED);
    }

    //--------------------------------------------------------------------------------------------
//supprimer un collaborateur
 @DeleteMapping("/collab/{id}")
    public ResponseEntity<Map<String,Boolean>> deletecollab(@PathVariable("id") Integer idcollab){

        return ResponseEntity.ok(collabService.deletecollab(idcollab));
 }



    //********************************************************gestion manager rh****************************************************************************
//ajouter manager
    @PostMapping ("/Managerrh")
    public ResponseEntity<Collaborateur> ajout_managerrh(@RequestBody() Collaborateur cl){
        return new ResponseEntity<>(collabService.creat_managerRH(cl), HttpStatus.CREATED);
    }
    //*****************************************************
//affecter colllab a mager
    @PutMapping ("/Managerrh")
    public ResponseEntity<Collaborateur> affecter_managerrh(Integer collaborateurId){
        return new ResponseEntity<>(collabService.assign_to_mangerRH(collaborateurId), HttpStatus.CREATED);
    }




}