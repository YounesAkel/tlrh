package com.fstg.gestion_tlrh;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GestionTlrhApplicationTests {

	@Test
	void contextLoads() {
	}

}
